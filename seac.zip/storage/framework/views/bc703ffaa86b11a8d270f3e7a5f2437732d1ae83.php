<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800"><b>Logs</b></h1>

<div class="form-group">
    <a href="<?php echo e(url('/admin/quiz')); ?>" class="btn btn-custom btn-outline-secondary"><i class="fa fa-arrow-circle-left"></i> <b>BACK</b></a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Score</th>
                        <th>Date & Time Taken</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        callDT();
    });

    function callDT() {
        $('#dataTable').DataTable({
            bDestroy: true,
            ajax: {
                url: "<?php echo e(url('/admin/quiz/logs/table')); ?>/" + "<?php echo e($id); ?>",
                dataSrc: ""
            },
            columns: [
                { data: 'name' },
                { data: 'score' },
                { data: 'created_at' },
            ],
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seac\resources\views/admin/quiz/logs.blade.php ENDPATH**/ ?>