<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800"><b>Teacher</b></h1>

<?php if(Auth::user()->user_type != 1): ?>
    <div class="text-center text-danger mt-5">
        <h4>Restricted! Only the administrator can access this point.</h4>
    </div>
<?php else: ?>
    <div class="form-group">
        <a href="<?php echo e(url('/admin/teacher/add')); ?>" class="btn btn-custom btn-success"><i class="fa fa-plus-square"></i> <b>ADD</b></a>
        <a href="<?php echo e(url('/admin/teacher/bin')); ?>" class="btn btn-custom btn-secondary float-right"><i class="fa fa-trash"></i> <b>BIN</b></a>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Sex</th>
                            <th>Date of Birth</th>
                            <th>Address</th>
                            <th>Nationality</th>
                            <th>Civil Status</th>
                            <th>Contact #</th>
                            <th></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        callDT();
    });

    function callDT() {
        $('#dataTable').DataTable({
            bDestroy: true,
            ajax: {
                url: "<?php echo e(url('/admin/teacher/table')); ?>",
                dataSrc: ""
            },
            columns: [
                { data: 'first_name' },
                { data: 'sex' },
                { data: 'date_birth' },
                { data: 'address' },
                { data: 'nationality' },
                { data: 'civil_status' },
                { data: 'contact_no' },
                {
                    data: 'id',
                    orderable: false,
                    render: function (data, type, row) {
                        return '<div class="text-right">'+
                                    '<div class="btn-group">'+
                                        '<a class="btn btn-danger btn-sm" onclick="remove('+data+') "title="Remove"><i class="fa fa-trash"></i></a>'+
                                        '<a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/teacher/update/')); ?>/'+data+'" title="Update"><i class="fa fa-edit"></i></a>'+
                                    '</div>'+
                                '</div>';
                    }
                }
            ],
        });
    }

    function remove(id) {
        $.confirm({
                animation: 'none',
                theme: 'light', 
                title: 'Remove',
                content: 'This teacher account will be removed, continue?',
                buttons: {
                    No: function () {

                    },
                    Yes: {
                        btnClass: 'btn-danger',
                        action: function(){
                            $.ajax({
                                url: '<?php echo e(url("admin/teacher/remove/")); ?>/'+id,
                                method: 'post',
                                success: function(result){
                                    if (result  == 'success') {
                                        $.alert({
                                            animation: 'none',
                                            theme: 'light',
                                            title: 'Success!',
                                            content: 'Teacher account has been removed.',
                                            buttons: {
                                                OK: function () {
                                                    callDT();
                                                },
                                            }
                                        });
                                    }
                                    else {
                                        $.alert({
                                            animation: 'none',
                                            theme: 'light',
                                            title: 'Failed!',
                                            content: 'Teacher account has failed to remove.'
                                        });
                                        console.log(result);
                                    }
                                }
                            });
                        }
                    },
                }
            });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seac\resources\views/admin/teacher/index.blade.php ENDPATH**/ ?>