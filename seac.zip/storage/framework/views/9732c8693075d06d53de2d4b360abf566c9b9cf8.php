<?php $__env->startSection('content'); ?>
<section id="browse">
    <div class="container mt-10 mb-5" data-aos="fade-up">

        <header class="section-header mb-5">
            <h3 class="section-title"><?php echo e($data['country']); ?></h3>
        </header>
        <div class="text-center mb-5">
            <a href="<?php echo e(url('browse')); ?>"><b>Return</b></a>
        </div>

        <div class="row browse-cols">
            <?php if(count($data['list']) == 0): ?>
                <div class="col-12 mt-5">
                    <h2 class="text-center">There are no items to browse yet</h2>
                </div>
            <?php else: ?>
                <div class="col-md-8 mx-auto" data-aos="fade-up" data-aos-delay="300">
                    <div class="row">
                        <?php if($data['list']->count() > 0): ?>
                            <?php $__currentLoopData = $data['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <div class="browse-col" onclick="window.location.href = '<?php echo e(url('browse').'/'.$item->id); ?>'">
                                        <div class="img">
                                            <img src="<?php echo e(asset('storage/browse').'/'.$item->image); ?>" alt="img" class="imgBrowse img-fluid">
                                        </div>
                                        <h2 class="title"><a href="#"><?php echo e($item->title); ?></a></h2>
                                        
                                        <p class="context"><?php echo e($item->context); ?></p>
                                        

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($data['list']->onEachSide(5)->links()); ?>

                        <?php else: ?>
                            <div class="col-12 mt-10">
                                <h2 class="text-center">No item found</h2>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="text-center mt-5">
            <a href="<?php echo e(url('browse')); ?>"><b>Return</b></a>
        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        //  $(document).ready(function() {
        //     var url_string = $('[name=video]').val();
        //     var url = new URL(url_string);
        //     var v = url.searchParams.get("v");

        //     var youtubeDiv = document.getElementById('youtubeVid');
        //     var data_id = youtubeDiv.getAttribute('data-id')
        //     $(data_id).html(
        //         '<div class="form-group">'+
        //             '<label><small>Youtube Video</small></label>'+
        //         '</div>'+
        //         '<div class="embed-responsive embed-responsive-16by9">'+
        //             '<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/'+v+'" allowfullscreen></iframe>'+
        //         '</div>'
        //     );

        // })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seac\resources\views/browseCountry.blade.php ENDPATH**/ ?>