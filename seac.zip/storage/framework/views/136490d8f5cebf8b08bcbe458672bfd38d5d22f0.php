<?php $__env->startSection('content'); ?>
<section id="browse">
    <div class="container mt-10 mb-5" data-aos="fade-up">

        <header class="section-header mb-5">
            <h3 class="section-title">Browse</h3>
        </header>

        <div class="row browse-cols">

            <?php if(App\Browse::count() == 0): ?>
                <div class="col-12 mt-10">
                    <h2 class="text-center">There are no items to browse yet</h2>
                </div>
            <?php else: ?>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="browse-col" style="padding: 20px">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" name="search" placeholder="Search Title . . .">
                            <div class="input-group-append">
                                <button id="btnSearch" class="btn btn-outline-secondary" onclick="window.location.href = '<?php echo e(url('browse?search=')); ?>' + $('[name=search]').val();">all</button>
                            </div>
                        </div>
                        <div class="mt-5">
                            <h2 class="text-left">Recently Posted</h2>
                            <ul class="list-group list-group-flush">
                                <?php $__currentLoopData = $data['rp']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse') . '/' . $item->id); ?>'"><?php echo e($item->title); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="mt-5">
                            <h2 class="text-left">Countries</h2>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Brunei')); ?>'">Brunei</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Burma')); ?>'">Burma (Myanmar)</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Cambodia')); ?>'">Cambodia</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Indonesia')); ?>'">Indonesia</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Laos')); ?>'">Laos</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Malaysia')); ?>'">Malaysia</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Philippines')); ?>'">Philippines</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Singapore')); ?>'">Singapore</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Thailand')); ?>'">Thailand</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Timor-leste')); ?>'">Timor-Leste</li>
                                <li class="list-group-item" onclick="window.location.href = '<?php echo e(url('browse-country/Vietnam')); ?>'">Vietnam</li>
                            </ul>-country
                        </div>
                    </div>
                </div>

                <div class="col-md-8" data-aos="fade-up" data-aos-delay="300">
                    <div class="row">
                        <?php if($data['items']->count() > 0): ?>
                            <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <div class="browse-col" onclick="window.location.href = '<?php echo e(url('browse').'/'.$item->id); ?>'">
                                        <div class="img">
                                            <img src="<?php echo e(asset('storage/browse').'/'.$item->image); ?>" alt="img" class="imgBrowse img-fluid">
                                        </div>
                                        <h2 class="title"><a href="#"><?php echo e($item->title); ?></a></h2>

                                        <div class="text-center mb-3">
                                            <small>Country: <?php echo e($item->country); ?></small>
                                            <br>
                                            <small>Posted By: <?php echo e(App\User::find($item->created_by)->name); ?></small>
                                            <br>
                                            <small>Date Posted: <?php echo e(date('m/d/Y', strtotime($item->created_at))); ?></small>
                                        </div>
                                        <p class="context"><?php echo e(Str::limit($item->context, 500)); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($data['items']->onEachSide(5)->links()); ?>

                        <?php else: ?>
                            <div class="col-12 mt-10">
                                <h2 class="text-center">No item found</h2>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $('[name=search]').on('keyup', function() {
        if ($(this).val().length > 0)
            $('#btnSearch').html('go');
        else
            $('#btnSearch').html('all');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seac\resources\views/browse.blade.php ENDPATH**/ ?>