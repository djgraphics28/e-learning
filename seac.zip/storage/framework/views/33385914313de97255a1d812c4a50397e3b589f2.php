<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800"><b>Bin</b></h1>

<div class="form-group">
    <a href="<?php echo e(url('/admin/student')); ?>" class="btn btn-custom btn-outline-secondary"><i class="fa fa-arrow-circle-left"></i> <b>BACK</b></a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Sex</th>
                        <th>Date of Birth</th>
                        <th>Address</th>
                        <th>Nationality</th>
                        <th>Civil Status</th>
                        <th>Contact #</th>
                        <th></th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        callDT();
    });

    function callDT() {
        $('#dataTable').DataTable({
            bDestroy: true,
            ajax: {
                url: "<?php echo e(url('/admin/student/bin/table')); ?>",
                dataSrc: ""
            },
            columns: [
                { data: 'first_name' },
                { data: 'sex' },
                { data: 'date_birth' },
                { data: 'address' },
                { data: 'nationality' },
                { data: 'civil_status' },
                { data: 'contact_no' },
                {
                    data: 'id',
                    orderable: false,
                    render: function (data, type, row) {
                        return '<div class="text-right">'+
                                    '<div class="btn-group">'+
                                        '<a class="btn btn-secondary btn-sm" onclick="restore('+data+') "title="Restore"><i class="fa fa-trash-restore"></i></a>'+
                                    '</div>'+
                                '</div>';
                    }
                }
            ],
        });
    }

    function restore(id) {
        $.confirm({
                animation: 'none',
                theme: 'light', 
                title: 'Restore',
                content: 'This student account will be restored, continue?',
                buttons: {
                    No: function () {

                    },
                    Yes: {
                        btnClass: 'btn-secondary',
                        action: function(){
                            $.ajax({
                                url: '<?php echo e(url("admin/student/restore/")); ?>/'+id,
                                method: 'post',
                                success: function(result){
                                    if (result  == 'success') {
                                        $.alert({
                                            animation: 'none',
                                            theme: 'light',
                                            title: 'Success!',
                                            content: 'Student account has been restored.',
                                            buttons: {
                                                OK: function () {
                                                    callDT();
                                                },
                                            }
                                        });
                                    }
                                    else {
                                        $.alert({
                                            animation: 'none',
                                            theme: 'light',
                                            title: 'Failed!',
                                            content: 'Student account has failed to restore.'
                                        });
                                        console.log(result);
                                    }
                                }
                            });
                        }
                    },
                }
            });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seac\resources\views/admin/student/bin.blade.php ENDPATH**/ ?>