NOTE ON HOW TO USE.

1. Download https://drive.google.com/drive/folders/1ED9D_vGFkeETcOW7jmEcONYbxBMgdSsW?usp=sharing
2. Put your downloaded recommended file based on your php version in xampp/php/ext folder
3. Configure php.ini in xampp/php/php.ini
4. Put "extension=bolt_name" on the bottom part.
5. Restart your server.
6. Clone the source code.
7. Create database named "seac_db".
8. Open Git Bash on the directory and run these codes;
9. composer install
10. php artisan migrate:fresh --seed
11. php artisan storage:link


username: admin@mail.com
password :admin

Done
