<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    // protected $fillable = [
    //     'country_name',
    //     'country_capital',
    //     'description',
    //     'image',
    // ];

    protected $table = 'country';
}
